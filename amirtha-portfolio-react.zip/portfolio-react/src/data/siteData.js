import { icons } from './icons.js'

export const skills = [
  { name: 'Figma',           level: 92, color: '#61f2ff', c2: '#b084ff' },
  { name: 'Photoshop',       level: 88, color: '#31a8ff', c2: '#61f2ff' },
  { name: 'Illustrator',     level: 84, color: '#ffd56a', c2: '#ff9a3d' },
  { name: 'Premiere Pro',    level: 86, color: '#b084ff', c2: '#61f2ff' },
  { name: 'After Effects',   level: 82, color: '#b084ff', c2: '#ff4d67' },
  { name: 'Canva',           level: 88, color: '#7d2ae8', c2: '#00c4cc' },
  { name: 'UI/UX Design',    level: 90, color: '#61f2ff', c2: '#78e06b' },
  { name: 'Motion Graphics', level: 80, color: '#78e06b', c2: '#ffd56a' },
  { name: 'Branding',        level: 84, color: '#ffd56a', c2: '#61f2ff' },
  { name: 'Typography',      level: 78, color: '#ff7a3d', c2: '#ffd56a' },
]

export const craftSlots = [
  { icon: icons.photoshop,   label: 'Photoshop',   color: '#31a8ff' },
  { icon: icons.figma,       label: 'Figma',        color: '#61f2ff' },
  { icon: icons.illustrator, label: 'Illustrator',  color: '#ffd56a' },
  { icon: icons.premiere,    label: 'Premiere Pro', color: '#b084ff' },
  { icon: icons.aftereffects,label: 'After Effects',color: '#c6a6ff' },
  { icon: icons.canva,       label: 'Canva',        color: '#7d2ae8' },
  { icon: icons.ux,          label: 'UI/UX',        color: '#84cfff' },
  { icon: icons.motion,      label: 'Motion',       color: '#78e06b' },
  { icon: icons.type,        label: 'Typography',   color: '#ff7a3d' },
]

export const filters = [
  'All','Graphic Design','Event Design','Poster Design',
  'Social Media','Video Editing','Branding',
]

export const timeline = [
  {
    date: '2025 — 2026',
    title: 'Design Team Member',
    company: 'DEVS · Rajalakshmi Engineering College',
    desc: 'Creating event posters, social media creatives, hackathon campaigns, and brand assets for DEVS — the tech club of REC. Designed posters for SIH 2025, Breach 101, XplorEx, Titanium 2026, Farewell Night, and more.',
    badges: ['Event Posters','Social Media','Branding','Typography'],
    color: '#61f2ff',
  },
  {
    date: '2025 — 2026',
    title: 'Design Contributor',
    company: 'Team Vikram · REC Aerospace Club',
    desc: 'Designed all visual communication for Team Vikram — a student rocketry team. Delivered Space Odyssey 2025 event poster, Christmas story, New Year 2026 countdown, Spacekidz competition congrats post, and the Starfeed Wrapped monthly newsletter.',
    badges: ['Space Visuals','Newsletter Design','Social Media'],
    color: '#ffd56a',
  },
  {
    date: '2024 — Present',
    title: 'Freelance Graphic Designer',
    company: 'Independent Creative Work',
    desc: 'Delivering poster designs, campaign creatives, and brand assets for clients including tuition centres, election campaigns, and personal creative projects. Work spans fan art edits, F1 sports posters, and film-inspired compositions.',
    badges: ['Poster Design','Campaign Design','Fan Edits'],
    color: '#78e06b',
  },
]

export const unlocks = [
  { icon: icons.spark,  title: 'DEVS Design Member',   sub: 'Rajalakshmi Engineering College · 2025–2026' },
  { icon: icons.trophy, title: 'Team Vikram Contributor', sub: 'REC Aerospace Club · 2025–2026' },
  { icon: icons.spark,  title: '25+ Design Projects',  sub: 'Event posters, fan edits & social creatives' },
  { icon: icons.trophy, title: 'Multi-Tool Designer',   sub: 'Photoshop · Figma · Canva · Illustrator · Ae' },
  { icon: icons.spark,  title: 'Freelance Designer',    sub: 'Client work from 2024 onwards' },
]

export const socials = [
  {
    icon: icons.instagram,
    label: 'Instagram',
    sub: '@_thatrebelkid.fx_',
    href: 'https://www.instagram.com/_thatrebelkid.fx_/?hl=en',
    color: '#e1306c',
  },
  {
    icon: icons.linkedin,
    label: 'LinkedIn',
    sub: 'amirtharengavathi',
    href: 'https://www.linkedin.com/in/amirtharengavathi',
    color: '#0a66c2',
  },
  {
    icon: icons.mail,
    label: 'Email',
    sub: 'amirtharengavathi@gmail.com',
    href: 'mailto:amirtharengavathi@gmail.com',
    color: '#61f2ff',
  },
  {
    icon: icons.phone,
    label: 'Phone',
    sub: '+91 7598536107',
    href: 'tel:+917598536107',
    color: '#78e06b',
  },
]
