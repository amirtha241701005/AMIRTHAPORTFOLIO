import { timeline, unlocks } from '../data/siteData.js'

function TimelineItem({ item }) {
  return (
    <div className="tl-item reveal">
      <div className="tl-marker" style={{ '--tl-color': item.color }} aria-hidden="true" />
      <div className="tl-content">
        <time className="tl-date" style={{ color: item.color }}>{item.date}</time>
        <h3 className="tl-title">{item.title}</h3>
        <p className="tl-company">{item.company}</p>
        <p className="tl-desc">{item.desc}</p>
        <div className="tl-badges" aria-label="Skills">
          {item.badges.map(b => (
            <span key={b} className="tl-badge" style={{ borderColor: item.color + '44', color: item.color }}>
              {b}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}

function UnlockCard({ item }) {
  return (
    <div className="unlock-card reveal">
      <div
        className="unlock-icon"
        dangerouslySetInnerHTML={{ __html: item.icon }}
        aria-hidden="true"
      />
      <div className="unlock-text">
        <div className="unlock-title">{item.title}</div>
        <div className="unlock-sub">{item.sub}</div>
      </div>
    </div>
  )
}

export default function Achievements() {
  return (
    <section id="achievements" className="ambient-section" aria-labelledby="ach-title">
      <div className="section-container">
        <div className="section-header reveal">
          <p className="section-kicker">// PLAYER.XP</p>
          <h2 id="ach-title" className="section-title">
            Experience <span className="accent">Log</span>
          </h2>
        </div>

        <div className="ach-grid">
          {/* Timeline */}
          <div className="timeline-wrap" id="timeline">
            <div className="tl-track" aria-hidden="true" />
            {timeline.map((item, i) => (
              <TimelineItem key={i} item={item} />
            ))}
          </div>

          {/* Unlocks */}
          <div className="unlocks-wrap">
            <p className="section-kicker" style={{ marginBottom: '28px' }}>
              // ACHIEVEMENTS.UNLOCKED
            </p>
            <div className="unlocks-grid" id="achievementBadges">
              {unlocks.map((u, i) => (
                <UnlockCard key={i} item={u} />
              ))}
            </div>

            <a
              href="https://drive.google.com/drive/folders/19upmE13-mbGe1p2o3iOUHuUKGa4GQMzy"
              target="_blank"
              rel="noopener noreferrer"
              className="drive-btn reveal"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3"/>
              </svg>
              View Full Portfolio
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
