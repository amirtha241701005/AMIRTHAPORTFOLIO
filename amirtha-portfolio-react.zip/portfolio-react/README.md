# Amirtha Rengavathi — Portfolio (React + Vite)

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start dev server
npm run dev

# 3. Build for production
npm run build

# 4. Preview production build
npm run preview
```

## Deploy to Vercel

```bash
# Option A — Vercel CLI
npm i -g vercel
vercel

# Option B — GitHub
# Push to GitHub → import repo on vercel.com → auto-deploys
```

Vercel settings:
- Framework: **Vite**
- Build command: `npm run build`
- Output directory: `dist`

---

## Project Structure

```
src/
├── App.jsx                    # Root — loader, nav, section composition
├── main.jsx                   # React DOM entry point
│
├── components/
│   ├── Cursor.jsx             # Pixel arrow cursor (chroma-keyed PNG)
│   ├── Cursor.module.css      # Cursor-specific scoped CSS
│   ├── Loader.jsx             # Minecraft-style loading screen
│   ├── Nav.jsx                # Fixed top navigation
│   ├── Minimap.jsx            # Fixed side section dots
│   ├── Hero.jsx               # Hero section + particles canvas
│   ├── About.jsx              # About + skill bars + crafting inventory
│   ├── Projects.jsx           # Filterable project grid
│   ├── Achievements.jsx       # Timeline + unlocks grid
│   └── Contact.jsx            # Social links + web3forms contact form
│
├── hooks/
│   ├── useCursor.js           # Pixel cursor with RAF loop + chroma-key
│   ├── useParticles.js        # Canvas particle system (60fps capped)
│   ├── useInView.js           # IntersectionObserver hook + scroll reveal
│   └── useActiveSection.js    # Tracks active section for minimap
│
├── data/
│   ├── icons.js               # All SVG icon strings
│   ├── siteData.js            # Skills, crafting slots, timeline, socials
│   └── projects.json          # 27 project entries with metadata
│
├── assets/
│   ├── bg.png                 # Minecraft valley background
│   ├── cursor.png             # Pixel arrow cursor (green-screen)
│   ├── project_00.jpg         # Project poster images (27 total)
│   └── project_**.{jpg,png}
│
└── styles/
    └── global.css             # Full site CSS (preserved from original)
```

## Key React Patterns Used

| Pattern | Where |
|---------|-------|
| `useState` | Filter state, form state, loader progress, XP bar |
| `useEffect` + cleanup | Cursor RAF loop, particles, observers |
| `useRef` | Canvas refs, cursor DOM refs |
| `useMemo` | Filtered projects (avoids re-filter on every render) |
| `useCallback` | Form handlers (stable references) |
| `IntersectionObserver` | Scroll reveal, active section, skill bar trigger |
| `requestAnimationFrame` | Cursor movement, particle animation |
| `lazy` + `Suspense` | Lazy-load below-fold sections |
| CSS Modules | Scoped cursor styles |
| `import.meta.glob` | Batch-import all project images (Vite feature) |

## Dependencies

```json
{
  "react": "^18.2.0",
  "react-dom": "^18.2.0",
  "@vitejs/plugin-react": "^4.2.1",
  "vite": "^5.2.0"
}
```

No other libraries needed. Zero runtime dependencies beyond React.

## Contact Form

Uses [web3forms.com](https://web3forms.com) — no backend required.
Access key: `ae13326e-299a-4d65-a6ac-7fbb595739a6`
To change it, update `ACCESS_KEY` in `src/components/Contact.jsx`.
